x=2
def f():
    x=3
    print(x)

print(x)

f()