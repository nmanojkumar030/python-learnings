def hi():
    print("Hello World")
hi()

greeting=hi
greeting()


