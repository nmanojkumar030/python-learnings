def calc(x,y):
    d={'sum':x+y,'diff':x-y,'prod':x*y,'quot':x/y}
    return d

result=calc(2,3)
print(result)


