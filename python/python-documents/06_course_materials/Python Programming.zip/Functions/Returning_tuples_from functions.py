def calc(x,y):
    t=(x+y,x-y,x*y,x/y)
    return t

result=calc(2,3)
print(result)