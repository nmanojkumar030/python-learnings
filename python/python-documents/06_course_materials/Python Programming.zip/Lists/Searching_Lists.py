L=[5,2,3,2]

print(3 in L)

print(4 in L)

print(4 not in L)

print(L.count(3))

print(L.count(2))

print(L.count(4))

print(L.index(2))

#print(L.index(4))--Error will be returned..Value 4 is not in list

print(L.index(2,2))

print(L.index(3,0,2))