my_list = ['p','r','o','g','r','a','m','i','z']

print(my_list[2:5])

print(my_list[:-5])

print(my_list[5:])

print(my_list[:])
