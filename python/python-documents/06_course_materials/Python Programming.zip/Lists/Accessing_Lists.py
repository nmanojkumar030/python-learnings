my_list = ['p','r','o','b','e']

print(my_list[0])


print(my_list[2])


print(my_list[4])

# Error! Only integer can be used for indexing
# my_list[4.0]

# Nested List
n_list = ["Happy", [2,0,1,5]]

# Nested indexing

print(n_list[0][1])

print(n_list[1][3])