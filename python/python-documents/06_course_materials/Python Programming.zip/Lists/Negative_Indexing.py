my_list = ['p','r','o','b','e']

print(my_list[-1])

print(my_list[-5])