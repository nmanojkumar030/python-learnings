# empty list
my_list = []
print(my_list)
# list of integers
my_list = [1, 2, 3]
print(my_list)
# list with mixed datatypes
my_list = [1, "Hello", 3.4]
print(my_list)